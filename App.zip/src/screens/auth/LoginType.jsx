import { SafeAreaView, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import Word from '../../components/common/word/Word'

const LoginType = () => {
  return (
    <SafeAreaView style={styles.container}>
        <Word text={'Choice Type'} size={20} font={6} color={'black'} tc={'center'}/>
    </SafeAreaView>
  )
}

export default LoginType

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#ffffff'
    }
})