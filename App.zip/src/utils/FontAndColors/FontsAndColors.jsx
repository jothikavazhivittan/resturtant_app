export const fonts={
    thin:'Roboto-Thin',
    extra_light:'Roboto-ExtraLight',
    light:'Roboto-Light',
    regular:'Roboto-Regular',
    medium:'Roboto-Medium',
    semi_bold:'Roboto-SemiBold',
    bold:'Roboto-Bold',
    extra_bold:'Roboto-ExtraBold',
    black:'Roboto-Black'
}

export const colors={
    white:'#ffffff',
    black:'#000000',
    gray:'#adb5bd'
}