import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { createStackNavigator } from '@react-navigation/stack'
import LoginScreen from '../screens/auth/LoginScreen'
import HomeScreen from '../screens/feed/HomeScreen'
import LoginType from '../screens/auth/LoginType'

const MainStackNavigator = () => {
    const Stack=createStackNavigator()
  return (
    <Stack.Navigator initialRouteName='login' screenOptions={{headerShown:false}}> 
        <Stack.Screen name='login' component={LoginScreen}/>
         <Stack.Screen name='home' component={HomeScreen}/>
         <Stack.Screen name='login_type' component={LoginType}/>
    </Stack.Navigator>
  )
}

export default MainStackNavigator

const styles = StyleSheet.create({}) 