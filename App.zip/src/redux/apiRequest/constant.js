export const BASE_URL = 'https://merger.ninositsolution.com/public/'; //live url
// export const BASE_URL = 'http://192.168.1.15/merger_laravel_backend/public/'; //local url
export const URL = {
  LOGIN: 'user/userlogin',

};
