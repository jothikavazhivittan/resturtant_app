export const see=require('./see.png')
export const search=require('./search.png')
export const light=require('./light.png')
export const background=require('./background.png')